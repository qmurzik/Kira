<?php echo 'Привет'; ?>
